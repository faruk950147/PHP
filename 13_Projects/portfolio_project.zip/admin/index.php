<?php
session_start();
include '../config.php';
include 'include/header.php';
include 'include/sidebar.php';
?>
<div class="container">
  <h1>Admin Dashboard</h1>
  <p>Welcome, admin.</p>
</div>
<?php include 'include/footer.php'; ?>