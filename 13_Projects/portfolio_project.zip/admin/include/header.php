<!doctype html>
<html>
<head><meta charset="utf-8"><title>Admin</title></head>
<body>
<header><h1>Admin Panel</h1></header>
