<?php
include '../../config.php';
if(isset($_POST['submit'])){
    $title = safe($_POST['title']);
    $file = $_FILES['image']['name'];
    $path = '../uploads/portfolio/' . time() . '_' . basename($file);
    move_uploaded_file($_FILES['image']['tmp_name'], '../../uploads/portfolio/' . basename($file));
    $conn->query("INSERT INTO portfolio (title, image) VALUES ('$title', '$path')");
    echo 'Uploaded';
}
?>
<form method="post" enctype="multipart/form-data">
  <input name="title" placeholder="title"><br>
  <input type="file" name="image"><br>
  <button name="submit">Upload</button>
</form>
