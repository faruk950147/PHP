<?php
session_start();
include '../config.php';

if(isset($_POST['login'])){
    $u = safe($_POST['username']);
    $p = safe($_POST['password']);

    $q = $conn->query("SELECT * FROM admin WHERE username='$u' AND password='$p'");
    if($q && $q->num_rows > 0){
        $_SESSION['admin'] = $u;
        header('Location: index.php');
        exit;
    } else {
        $error = 'Invalid Login!';
    }
}
?>
<!doctype html>
<html>
<body>
<h2>Admin Login</h2>
<?php if(isset($error)) echo '<p>'.$error.'</p>'; ?>
<form method="post">
  <input name="username" placeholder="username"><br>
  <input name="password" placeholder="password" type="password"><br>
  <button name="login">Login</button>
</form>
</body>
</html>
