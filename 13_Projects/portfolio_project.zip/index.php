<?php
include 'config.php';
include 'include/header.php';
include 'include/navbar.php';

// Sections
include 'sections/hero-section/index.php';
include 'sections/about/index.php';
include 'sections/services/index.php';
include 'sections/portfolio/index.php';
include 'sections/skills/index.php';
include 'sections/experience/index.php';
include 'sections/testimonials/index.php';
include 'sections/contact/index.php';

include 'include/footer.php';
?>