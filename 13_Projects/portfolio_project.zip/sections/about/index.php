<?php // about section ?>
<section id="about">
  <h2>About</h2>
  <p>Content for about.</p>
</section>
