<?php // testimonials section ?>
<section id="testimonials">
  <h2>Testimonials</h2>
  <p>Content for testimonials.</p>
</section>
