<?php // contact section ?>
<section id="contact">
  <h2>Contact</h2>
  <p>Content for contact.</p>
</section>
