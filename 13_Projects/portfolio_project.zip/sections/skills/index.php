<?php // skills section ?>
<section id="skills">
  <h2>Skills</h2>
  <p>Content for skills.</p>
</section>
