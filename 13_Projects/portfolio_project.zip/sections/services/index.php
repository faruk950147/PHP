<?php // services section ?>
<section id="services">
  <h2>Services</h2>
  <p>Content for services.</p>
</section>
