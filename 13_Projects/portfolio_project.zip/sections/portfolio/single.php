<?php
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
echo '<h1>Portfolio item ' . $id . '</h1>';
?>