<?php // portfolio section ?>
<section id="portfolio">
  <h2>Portfolio</h2>
  <p>Content for portfolio.</p>
</section>
