<?php // hero-section section ?>
<section id="hero-section">
  <h2>Hero Section</h2>
  <p>Content for hero-section.</p>
</section>
