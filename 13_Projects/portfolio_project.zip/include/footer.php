<footer>
  <p>&copy; <?= date('Y') ?> My Portfolio</p>
</footer>
</body>
</html>
