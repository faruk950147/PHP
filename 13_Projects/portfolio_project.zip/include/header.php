<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>My Portfolio</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
