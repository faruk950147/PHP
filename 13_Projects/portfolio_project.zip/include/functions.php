<?php
function elapsed($ts){
    return date('Y', time()) - date('Y', strtotime($ts));
}
?>