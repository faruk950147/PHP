<?php
include 'db.php';

function safe($value) {
    global $conn;
    return mysqli_real_escape_string($conn, $value);
}
?>